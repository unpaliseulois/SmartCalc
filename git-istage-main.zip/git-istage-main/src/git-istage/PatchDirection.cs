using System;

namespace GitIStage
{
    internal enum PatchDirection
    {
        Stage,
        Unstage,
        Reset
    }
}